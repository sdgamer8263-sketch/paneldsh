# VortexJS

Welcome to 🚀 **VortexJS**! 

This egg is fully open and ready to use — simple, fast, and hassle-free.

## Getting Started

1. **Import the Egg**  
   Add this egg to your Pterodactyl panel like any other egg.

2. **Create Your Server**  
   Spin up a new server using VortexJS — installation is automatic.

3. **Enjoy**  
   Start coding and running your projects in no time.

## Features

- ✅ Extremely **simple** to set up 
- Supports **npm**, **yarn**, and **pnpm** 
- Lightweight and efficient  
- Works with multiple Node.js versions:
  - NodeJS 18 (EOL)  
  - NodeJS 20 (LTS)  
  - NodeJS 22 (LTS)  
  - NodeJS 24 (LTS)  
  - NodeJS Latest  

## Support

If you need help or have questions, join our Discord: [discord.vortexnew.qzz.io](https://discord.vortexnew.qzz.io)

---

Made with love by **VortexDevelopment** ❤️
╭━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━╮
╰━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━╯

█░░░█ █▀▀ █░░ █▀▀ █▀▀█ █▀▄▀█ █▀▀
█▄█▄█ █▀▀ █░░ █░░ █░░█ █░▀░█ █▀▀
░▀░▀░ ▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀▀ ▀░░░▀ ▀▀▀

Hello %%__USERNAME__%%,
I'm ItsPhill_, the author of this resoruce, Thank you for purchasing my resoruce :)!

Please if you can leave a review on MC-MARKET, It will support me a lot!

Resource Name: ULTRA CHESE PTERODACTYL THEME
Resource Link: \\

╭━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━╮
╰━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━╯

█ █▄░█ █▀ ▀█▀ █▀█ █░█ █▀▀ ▀█▀ █ █▀█ █▄░█ █▀
█ █░▀█ ▄█ ░█░ █▀▄ █▄█ █▄▄ ░█░ █ █▄█ █░▀█ ▄█
_________________

1. Drag the resources folder to your pterodactyl directory.
2. Install node js & yarn (https://themes.pterodox.com/guides/building.html#install-dependencies)
4. run "yarn install"
5. Drag the tailwind.config.js into your pterodactyl directory.
6. run yarn build:production

╭━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━╮
╰━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━╯

█▀ █░█ █▀█ █▀█ █▀█ █▀█ ▀█▀
▄█ █▄█ █▀▀ █▀▀ █▄█ █▀▄ ░█░ 

If you need help please contact me on:

Discord Server: https://discord.gg/gmwdvc9FHW
Discord Contact: ItsPhill_#7679
╭━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━╮
╰━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━╯

█░█ █▀▀ █▀█ █▀ █ █▀█ █▄░█ █▀ 
▀▄▀ ██▄ █▀▄ ▄█ █ █▄█ █░▀█ ▄█ 

Resource Version: %%__VERSION__%%
Panels Version Supported: 1.X

╭━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━╮
╰━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━╯

█░█ █▀█ █▀▄ ▄▀█ ▀█▀ █▀▀
█▄█ █▀▀ █▄▀ █▀█ ░█░ ██▄

If you want to update the your server, check the "Update" 
folder and move the files on your server.

╭━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━╮
╰━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━╯


▀█▀ █▀▀ █▀█ █▀▄▀█ █▀   ▄▀█ █▄░█ █▀▄   █▀▀ █▀█ █▄░█ █▀▄ █ ▀█▀ █ █▀█ █▄░█ █▀
░█░ ██▄ █▀▄ █░▀░█ ▄█   █▀█ █░▀█ █▄▀   █▄▄ █▄█ █░▀█ █▄▀ █ ░█░ █ █▄█ █░▀█ ▄█
Resource TOS:​

1) You can require a refund only in acceptable case or for payment problems.
2) You cannot distribute this resource.
3) You cannot show / distribute / sell configurations or other files.
4) Any type of assistance request in reviews will be reported and removed.
5) Any type of bad review left before contacting the author for support will be reported and removed.
6) In case of suspicion of inappropriate use of the resource the license will be canceled.
7) This Terms and Conditions can be changed.

(You have accepted these Terms And Conditions when you have purchased the resource)

╭━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━┳━━╮
╰━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━┻━━╯
